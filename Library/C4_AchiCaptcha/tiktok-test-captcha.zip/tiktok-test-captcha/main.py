from helper import helper
from time import sleep
import random
from config import CONFIG
import requests
import base64
import time
HOTMAIL_ACCOUNT = "burneybddsoalse.q.r.w.7259@gmail.com|NT1dd2AuMkkUSUpKH"


def resolverTwoObject(imgUrl):
    response = requests.get(imgUrl)
    base64_image = base64.b64encode(response.content).decode("utf-8")
    API = "a9400341-2aae-43ae-b386-2ab1adeed9e7"
    data = {
        "clientKey": API,
        "task": {
            "type": "TiktokCaptchaTask",
            "image": base64_image,
            "subType": 2
        }
    }

    url = "http://api.achitech.site/createTask"
    response = requests.post(url, json=data).json()
    if response['errorId'] == 0:
        taskID = response['taskId']
        for i in range(20):
            time.sleep(1)
            response = requests.post("http://api.achitech.site/getTaskResult",
                                     json={"clientKey": API, "taskId": taskID})
            response = response.json()
            if response['errorId'] == 0 and response['status'] == "ready":
                result = response['solution']
                if ',' in result:
                    result = result.split(",")
                    x1 = int(result[0]) * 340 / 552
                    y1 = int(result[1]) * 212 / 344
                    x2 = int(result[2]) * 340 / 552
                    y2 = int(result[3]) * 212 / 344
                    return [x1, y1, x2, y2]
                else:
                    return None
    return None


class Reg789bet():
    def reg(self):
        user = HOTMAIL_ACCOUNT.split("|")[0]
        password = HOTMAIL_ACCOUNT.split("|")[1]
        helper.register(user, password)
        helper.driver.quit()


if __name__ == "__main__":
    # Reg789bet().reg()

    helper.resolverTwoObject(
        "https://lf19-captcha-sign.ibytedtos.com/obj/captcha-dl-sgp/3d_2385_f137a12901940c9f7c3bfb2783ad7d8f47d9e2a7_1.jpg?x-expires=1678033241&x-signature=GCac5zLtJuQblG0bg8Ex6wiQV1Q%3D")
