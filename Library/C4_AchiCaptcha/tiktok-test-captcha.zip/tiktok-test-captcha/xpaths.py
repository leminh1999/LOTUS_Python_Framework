class Xpaths():
    EMAIL_INPUT = '//*[@id="TikTokAds_Register-formitems-email"]/div/div[2]/input'
    PASSWORD_INPUT = '//*[@id="TikTokAds_Register-formitems-password"]/div/div/div/input'
    CHECK_BTN = "/html/body/div[1]/div[1]/div[2]/div/div/div[2]/div/div/div[2]/div/div[1]/form/div[4]/div[1]/div[1]/div/span"
    SIGN_UP_BTN = '//*[@id="TikTokAds_Register-register-button"]'
    CAPTCHA_IMG = '//*[@id="captcha-verify-image"]'
    CAPTCHA_TWO_OBJECT = '//*[@id="captcha-verify-image"]'
    CAPTCHA_ROTATE = '//*[@class="captcha_verify_container"]'
    CAPTCHA_SLIDER = '//*[@class="captcha_verify_container"]'


    REFRESH_BTN = '//*[@id="TikTokAds_Register-slide-container"]/div/div[3]/div[1]/a[1]'
    CONFIRM_BTN = '//*[@id="TikTokAds_Register-slide-container"]/div/div[3]/div[2]'


XPATH = Xpaths()
