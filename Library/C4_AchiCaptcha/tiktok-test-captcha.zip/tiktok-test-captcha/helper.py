import time

import selenium
from selenium import webdriver
from time import sleep
import logging
import requests
import base64
from io import BytesIO
from config import CONFIG
from xpaths import XPATH
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains

logging.basicConfig(
    format="%(asctime)s %(levelname)s:%(message)s", level=logging.INFO)


class Helper:
    def get_element(self, driver, XPATH):
        return driver.find_element(
            by=By.XPATH,
            value=XPATH,
        )

    def wait_and_find_element(self, driver, XPATH: str, timeout=100):
        WebDriverWait(driver, timeout).until(
            EC.presence_of_element_located(
                (
                    By.XPATH,
                    XPATH,
                )
            )
        )

        return driver.find_element(
            by=By.XPATH,
            value=XPATH,
        )

    @staticmethod
    def resolverTwoObject(imgUrl):
        response = requests.get(imgUrl)
        base64_image = base64.b64encode(response.content).decode("utf-8")
        API = "a9400341-2aae-43ae-b386-2ab1adeed9e7"
        data = {
            "clientKey": API,
            "task": {
                "type": "TiktokCaptchaTask",
                "image": base64_image,
                "subType": 2
            }
        }

        url = "http://api.achitech.site/createTask"
        response = requests.post(url, json=data).json()
        if response['errorId'] == 0:
            taskID = response['taskId']
            for i in range(20):
                time.sleep(1)
                response = requests.post("http://api.achitech.site/getTaskResult",
                                         json={"clientKey": API, "taskId": taskID})
                response = response.json()
                if response['errorId'] == 0 and response['status'] == "ready":
                    result = response['solution']
                    if ',' in result:
                        result = result.split(",")
                        x1 = int(result[0]) * 340 / 552
                        y1 = int(result[1]) * 212 / 344
                        x2 = int(result[2]) * 340 / 552
                        y2 = int(result[3]) * 212 / 344
                        return [x1, y1, x2, y2]
                    else:
                        return None
        return None

    @staticmethod
    def send_to_captcha_server(img_path, type):
        data = {
            "clientKey": CONFIG.CAPTCHA_API_KEY,
            "task": {
                "type": "TiktokCaptchaTask",
                "image": base64.b64encode(open(img_path, "rb").read()).decode("utf-8"),
                "subType": type
            }
        }
        response = requests.post(CONFIG.CAPTCHA_API_SUBMIT_TASK, json=data)
        response = response.json()
        taskID = response['taskId']
        result = None
        for i in range(20):
            time.sleep(1)
            response = requests.post(CONFIG.CAPTCHA_API_GET_TASK_RESULT,
                                     json={"clientKey": CONFIG.CAPTCHA_API_KEY, "taskId": taskID})
            response = response.json()
            if response['errorId'] == 0 and response['status'] == "ready":
                result = response['solution']
                x1 = int(result[0]) * 340 / 552
                y1 = int(result[1]) * 212 / 344
                x2 = int(result[2]) * 340 / 552
                y2 = int(result[3]) * 212 / 344
                result = [x1, y1, x2, y2]
                break
        return result

    def solveCaptchaSlider(self):
        pass

    def solveCaptchaTwoObject(self):
        captcha_img = self.wait_and_find_element(self.driver, XPATH.CAPTCHA_TWO_OBJECT, timeout=20)
        captcha_img.screenshot("captcha.png")
        response = self.send_to_captcha_server("captcha.png", CONFIG.TYPE_TWO_OBJECT_CAPTCHA)
        if response is not None:
            response = response.split(",")
            print("Response from server captcha: ", response)
            actions = ActionChains(self.driver)
            x1 = int(response[0])
            y1 = int(response[1])
            x2 = int(response[2])
            y2 = int(response[3])
            w, h = captcha_img.size['width'], captcha_img.size['height']
            actions.move_to_element_with_offset(captcha_img, x1 - w / 2, y1 - h / 2)
            actions.click()
            actions.perform()
            time.sleep(0.5)
            actions.move_to_element_with_offset(captcha_img, x2 - w / 2, y2 - h / 2)
            actions.click()
            actions.perform()
            return True
        else:
            # Retry
            return False

    def solveCaptchaRotate(self):
        pass

    def register(self, username, password):
        print(f"Registering: {username} {password}")
        self.options = webdriver.ChromeOptions()
        self.options.add_argument("--start-maximized")
        self.options.add_argument(
            "--no-first-run --no-service-autorun --password-store=basic"
        )
        # proxy = self.getNewTMProxy()
        # if proxy == "":
        #     proxy = self.getCurrentProxy()
        # self.options.add_argument(f"--proxy-server={proxy}")
        # self.options.add_argument("--headless")

        self.driver = uc.Chrome(
            options=self.options, executable_path=CONFIG.DRIVER_PATH
        )

        try:
            self.driver.get("https://ads.tiktok.com/i18n/signup")
            self.wait_and_find_element(
                self.driver, XPATH.EMAIL_INPUT).send_keys(username)
            time.sleep(2)
            self.wait_and_find_element(
                self.driver, XPATH.PASSWORD_INPUT).send_keys(password + "!?")
            # self.wait_and_find_element(
            #     self.driver, XPATH.CHECK_BTN).click()
            time.sleep(2)
            self.driver.find_element(
                by=By.ID,
                value="TikTokAds_Register-aggrement-guidline",
            ).click()
            time.sleep(2)
            self.wait_and_find_element(
                self.driver, XPATH.SIGN_UP_BTN).click()
            time.sleep(3)
            html = self.driver.page_source
            if "Drag the slider to fit the puzzle" in html:
                print("Solving captcha slider")
                self.solveCaptchaSlider()
            elif "Drag the puzzle piece into place" in html:
                print("Solving captcha rotate")
                self.solveCaptchaRotate()
            elif "Select 2 objects that are the same shape" in html:
                print("Solving captcha same shape")
                self.solveCaptchaTwoObject()
            time.sleep(1000)
        except Exception as e:
            print(e)
            return

    def getNewTMProxy(self):
        url = "https://tmproxy.com/api/proxy/get-new-proxy"
        header = {
            "accept": "application/json",
            "Content-Type": "application/json"
        }
        payload = {
            "api_key": CONFIG.API_KEY_TM,
            "id_location": CONFIG.PROXY_TYPE
        }

        rq = requests.post(url, headers=header, json=payload)
        print(
            f"PROXY: {rq.json()['data']['https']}\nLOCATION: {rq.json()['data']['location_name']}")
        return rq.json()["data"]["https"]

    def getCurrentProxy(self):
        url = "https://tmproxy.com/api/proxy/get-current-proxy"
        header = {
            "accept": "application/json",
            "Content-Type": "application/json"
        }
        payload = {
            "api_key": CONFIG.API_KEY_TM,
        }
        rq = requests.post(url, headers=header, json=payload)
        print(
            f"PROXY: {rq.json()['data']['https']}\nLOCATION: {rq.json()['data']['location_name']}")
        return rq.json()["data"]["https"]

    def test(self):
        self.options = webdriver.ChromeOptions()
        self.options.add_argument("--start-maximized")
        self.options.add_argument(
            "--no-first-run --no-service-autorun --password-store=basic"
        )
        proxy = self.getNewTMProxy()
        if proxy == "":
            proxy = self.getCurrentProxy()
        self.options.add_argument(f"--proxy-server={proxy}")
        self.driver = uc.Chrome(
            options=self.options, executable_path="chromedriver"
        )
        self.driver.get("https://whatismyipaddress.com/vi-vn/index")


helper = Helper()
