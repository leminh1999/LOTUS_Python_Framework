class Config:
    DRIVER_PATH = "chromedriver"
    CAPTCHA_API_SUBMIT_TASK = "http://api.achicaptcha.com/createTask"
    CAPTCHA_API_GET_TASK_RESULT = "http://api.achicaptcha.com/getTaskResult"
    CAPTCHA_API_KEY = "YOUR_KEY"
    TYPE_ROTATED_CAPTCHA = 0
    TYPE_SLIDER_CAPTCHA = 1
    TYPE_TWO_OBJECT_CAPTCHA = 2


CONFIG = Config()
