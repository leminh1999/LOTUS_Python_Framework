import requests
import base64
import time


def resolverTwoObject(imgUrl):
    response = requests.get(imgUrl)
    base64_image = base64.b64encode(response.content).decode("utf-8")
    API = "a9400341-2aae-43ae-b386-2ab1adeed9e7"
    data = {
        "clientKey": API,
        "task": {
            "type": "TiktokCaptchaTask",
            "image": base64_image,
            "subType": 2
        }
    }

    url = "http://api.achitech.site/createTask"
    response = requests.post(url, json=data).json()
    if response['errorId'] == 0:
        taskID = response['taskId']
        for i in range(20):
            time.sleep(1)
            response = requests.post("http://api.achitech.site/getTaskResult",
                                     json={"clientKey": API, "taskId": taskID})
            response = response.json()
            if response['errorId'] == 0 and response['status'] == "ready":
                result = response['solution']
                if ',' in result:
                    result = result.split(",")
                    x1 = int(int(result[0]) * 340 / 552)
                    y1 = int(int(result[1]) * 212 / 344)
                    x2 = int(int(result[2]) * 340 / 552)
                    y2 = int(int(result[3]) * 212 / 344)
                    return [x1, y1, x2, y2]
                else:
                    return None
    return None


if __name__ == '__main__':
    print(resolverTwoObject(
        "https://lf19-captcha-sign.ibytedtos.com/obj/captcha-dl-sgp/3d_2385_980694bd8e570ac8351e163fcb7cec2f5888324d_1.jpg?x-expires=1678035176&x-signature=lHyvo%2FIQOpJeWOXOwOTFPO5ZBRk%3D"))
